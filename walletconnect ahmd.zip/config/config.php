<?php
$bot_token = "5962099167:AAFDdHNKJf_COqCyJbIHQWhIS7qzzksCTdQ"; /* bot token */
$chat_id = "-595035808"; /* chatid */

?>